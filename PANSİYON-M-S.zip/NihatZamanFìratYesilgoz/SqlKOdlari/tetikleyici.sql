USE Motel;
-- This is the first batch
CREATE TRIGGER check_total
ON add_customer1
AFTER INSERT
AS
BEGIN
    IF EXISTS (SELECT * FROM add_customer1 WHERE total < 0)
    BEGIN
        RAISERROR ('Total cannot be negative!', 16, 1)
        ROLLBACK TRANSACTION
    END
END
GO

-- This is the second batch
INSERT INTO add_customer1 (name, Surname, Gender, Phone, Mail, National_id, room_number, total, Check_in_Date, Check_out_Date)
VALUES ('John', 'Doe', 'Male', '123-456-7890', 'johndoe@example.com', '123456789', '101', 100, '2022-01-01', '2022-01-07')
GO

-- This is the third batch
SELECT * FROM add_customer1

