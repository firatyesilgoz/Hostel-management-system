use Motel
CREATE PROCEDURE getTotalUserCount
AS
BEGIN
    SELECT COUNT(*) AS 'Total Users'
    FROM employee
END
EXEC getTotalUserCount

CREATE PROCEDURE calculate_total_employees
BEGIN
    DECLARE total_employees INT;

    SELECT COUNT(*) INTO total_employees
    FROM employee

    SET total_employees = total_employees * 2000;

    SELECT total_employees
END