USE MOTEL;

CREATE VIEW customer_view1 AS
SELECT Customer_id, name, Surname,Gender, Phone, Mail,National_id, room_number,total, Check_in_Date, Check_out_Date
FROM add_customer1;
