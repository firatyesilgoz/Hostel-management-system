use Motel;

DECLARE customer_cursor CURSOR FOR
    SELECT name, Surname
    FROM add_customer1;

OPEN customer_cursor;--imleci acarak satirlari almaya baslar
FETCH NEXT FROM customer_cursor;--imlecten sonraki satiri almak icin 
CLOSE customer_cursor; --Kapatmak icin
DEALLOCATE customer_cursor; --Silmek icin
