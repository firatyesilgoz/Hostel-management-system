﻿namespace PansiyonOtomasyonu
{
    partial class NewCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewCustomer));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.rtotal = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rsave = new System.Windows.Forms.Button();
            this.rcheckoutdate = new System.Windows.Forms.DateTimePicker();
            this.rcheckindate = new System.Windows.Forms.DateTimePicker();
            this.rphone = new System.Windows.Forms.MaskedTextBox();
            this.rroomno = new System.Windows.Forms.TextBox();
            this.rnationalid = new System.Windows.Forms.TextBox();
            this.rmail = new System.Windows.Forms.TextBox();
            this.rsurname = new System.Windows.Forms.TextBox();
            this.rname = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rroom109 = new System.Windows.Forms.Button();
            this.rroom108 = new System.Windows.Forms.Button();
            this.rroom107 = new System.Windows.Forms.Button();
            this.rroom106 = new System.Windows.Forms.Button();
            this.rroom105 = new System.Windows.Forms.Button();
            this.rroom104 = new System.Windows.Forms.Button();
            this.rroom103 = new System.Windows.Forms.Button();
            this.rroom102 = new System.Windows.Forms.Button();
            this.rroom101 = new System.Windows.Forms.Button();
            this.rFree = new System.Windows.Forms.Button();
            this.rfilled = new System.Windows.Forms.Button();
            this.nback = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.rtotal);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.rsave);
            this.groupBox1.Controls.Add(this.rcheckoutdate);
            this.groupBox1.Controls.Add(this.rcheckindate);
            this.groupBox1.Controls.Add(this.rphone);
            this.groupBox1.Controls.Add(this.rroomno);
            this.groupBox1.Controls.Add(this.rnationalid);
            this.groupBox1.Controls.Add(this.rmail);
            this.groupBox1.Controls.Add(this.rsurname);
            this.groupBox1.Controls.Add(this.rname);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(41, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(531, 513);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Infos";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(477, 475);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 41;
            this.label11.Text = "0";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Man",
            "Women"});
            this.comboBox1.Location = new System.Drawing.Point(267, 130);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(171, 21);
            this.comboBox1.TabIndex = 40;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(100, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 30);
            this.label10.TabIndex = 39;
            this.label10.Text = "Gender :";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // rtotal
            // 
            this.rtotal.Enabled = false;
            this.rtotal.Location = new System.Drawing.Point(267, 333);
            this.rtotal.Name = "rtotal";
            this.rtotal.Size = new System.Drawing.Size(171, 20);
            this.rtotal.TabIndex = 38;
            this.rtotal.TextChanged += new System.EventHandler(this.rtotal_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(100, 323);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 30);
            this.label9.TabIndex = 37;
            this.label9.Text = "Total :";
            // 
            // rsave
            // 
            this.rsave.BackColor = System.Drawing.Color.Transparent;
            this.rsave.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rsave.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.rsave.Location = new System.Drawing.Point(303, 471);
            this.rsave.Name = "rsave";
            this.rsave.Size = new System.Drawing.Size(135, 36);
            this.rsave.TabIndex = 36;
            this.rsave.Text = "Payment";
            this.rsave.UseVisualStyleBackColor = false;
            this.rsave.Click += new System.EventHandler(this.rsave_Click);
            // 
            // rcheckoutdate
            // 
            this.rcheckoutdate.CalendarFont = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rcheckoutdate.Location = new System.Drawing.Point(267, 413);
            this.rcheckoutdate.Name = "rcheckoutdate";
            this.rcheckoutdate.Size = new System.Drawing.Size(171, 20);
            this.rcheckoutdate.TabIndex = 35;
            this.rcheckoutdate.ValueChanged += new System.EventHandler(this.rchechoutdate_ValueChanged);
            // 
            // rcheckindate
            // 
            this.rcheckindate.CalendarFont = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rcheckindate.Location = new System.Drawing.Point(267, 373);
            this.rcheckindate.Name = "rcheckindate";
            this.rcheckindate.Size = new System.Drawing.Size(171, 20);
            this.rcheckindate.TabIndex = 34;
            // 
            // rphone
            // 
            this.rphone.Location = new System.Drawing.Point(267, 170);
            this.rphone.Mask = "(999) 000-0000";
            this.rphone.Name = "rphone";
            this.rphone.Size = new System.Drawing.Size(171, 20);
            this.rphone.TabIndex = 33;
            // 
            // rroomno
            // 
            this.rroomno.Enabled = false;
            this.rroomno.Location = new System.Drawing.Point(267, 293);
            this.rroomno.Name = "rroomno";
            this.rroomno.Size = new System.Drawing.Size(171, 20);
            this.rroomno.TabIndex = 32;
            // 
            // rnationalid
            // 
            this.rnationalid.Location = new System.Drawing.Point(267, 253);
            this.rnationalid.Name = "rnationalid";
            this.rnationalid.Size = new System.Drawing.Size(171, 20);
            this.rnationalid.TabIndex = 31;
            // 
            // rmail
            // 
            this.rmail.Location = new System.Drawing.Point(267, 210);
            this.rmail.Name = "rmail";
            this.rmail.Size = new System.Drawing.Size(171, 20);
            this.rmail.TabIndex = 30;
            // 
            // rsurname
            // 
            this.rsurname.Location = new System.Drawing.Point(267, 90);
            this.rsurname.Name = "rsurname";
            this.rsurname.Size = new System.Drawing.Size(171, 20);
            this.rsurname.TabIndex = 29;
            // 
            // rname
            // 
            this.rname.Location = new System.Drawing.Point(267, 50);
            this.rname.Name = "rname";
            this.rname.Size = new System.Drawing.Size(171, 20);
            this.rname.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(100, 403);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(171, 30);
            this.label8.TabIndex = 27;
            this.label8.Text = "Check out Date :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(100, 363);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 30);
            this.label7.TabIndex = 26;
            this.label7.Text = "Check in Date :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(100, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 30);
            this.label6.TabIndex = 25;
            this.label6.Text = "Room No :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(100, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 30);
            this.label5.TabIndex = 24;
            this.label5.Text = "National ID :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(100, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 30);
            this.label4.TabIndex = 23;
            this.label4.Text = "Mail :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(100, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 30);
            this.label3.TabIndex = 22;
            this.label3.Text = "Phone :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(100, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 30);
            this.label2.TabIndex = 21;
            this.label2.Text = "Surname :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(100, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 30);
            this.label1.TabIndex = 20;
            this.label1.Text = "Name :";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.rroom109);
            this.groupBox2.Controls.Add(this.rroom108);
            this.groupBox2.Controls.Add(this.rroom107);
            this.groupBox2.Controls.Add(this.rroom106);
            this.groupBox2.Controls.Add(this.rroom105);
            this.groupBox2.Controls.Add(this.rroom104);
            this.groupBox2.Controls.Add(this.rroom103);
            this.groupBox2.Controls.Add(this.rroom102);
            this.groupBox2.Controls.Add(this.rroom101);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(616, 34);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(429, 513);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rooms";
            // 
            // rroom109
            // 
            this.rroom109.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom109.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom109.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom109.Location = new System.Drawing.Point(311, 365);
            this.rroom109.Name = "rroom109";
            this.rroom109.Size = new System.Drawing.Size(78, 41);
            this.rroom109.TabIndex = 8;
            this.rroom109.Text = "109";
            this.rroom109.UseVisualStyleBackColor = false;
            this.rroom109.Click += new System.EventHandler(this.rroom109_Click);
            // 
            // rroom108
            // 
            this.rroom108.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom108.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom108.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom108.Location = new System.Drawing.Point(179, 365);
            this.rroom108.Name = "rroom108";
            this.rroom108.Size = new System.Drawing.Size(78, 41);
            this.rroom108.TabIndex = 7;
            this.rroom108.Text = "108";
            this.rroom108.UseVisualStyleBackColor = false;
            this.rroom108.Click += new System.EventHandler(this.rroom108_Click);
            // 
            // rroom107
            // 
            this.rroom107.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom107.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom107.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom107.Location = new System.Drawing.Point(44, 365);
            this.rroom107.Name = "rroom107";
            this.rroom107.Size = new System.Drawing.Size(78, 41);
            this.rroom107.TabIndex = 6;
            this.rroom107.Text = "107";
            this.rroom107.UseVisualStyleBackColor = false;
            this.rroom107.Click += new System.EventHandler(this.rroom107_Click);
            // 
            // rroom106
            // 
            this.rroom106.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom106.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom106.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom106.Location = new System.Drawing.Point(311, 226);
            this.rroom106.Name = "rroom106";
            this.rroom106.Size = new System.Drawing.Size(78, 47);
            this.rroom106.TabIndex = 5;
            this.rroom106.Text = "106";
            this.rroom106.UseVisualStyleBackColor = false;
            this.rroom106.Click += new System.EventHandler(this.rroom106_Click);
            // 
            // rroom105
            // 
            this.rroom105.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom105.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom105.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom105.Location = new System.Drawing.Point(179, 226);
            this.rroom105.Name = "rroom105";
            this.rroom105.Size = new System.Drawing.Size(78, 47);
            this.rroom105.TabIndex = 4;
            this.rroom105.Text = "105";
            this.rroom105.UseVisualStyleBackColor = false;
            this.rroom105.Click += new System.EventHandler(this.rroom105_Click);
            // 
            // rroom104
            // 
            this.rroom104.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom104.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom104.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom104.Location = new System.Drawing.Point(44, 226);
            this.rroom104.Name = "rroom104";
            this.rroom104.Size = new System.Drawing.Size(78, 47);
            this.rroom104.TabIndex = 3;
            this.rroom104.Text = "104";
            this.rroom104.UseVisualStyleBackColor = false;
            this.rroom104.Click += new System.EventHandler(this.rroom104_Click);
            // 
            // rroom103
            // 
            this.rroom103.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom103.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom103.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom103.Location = new System.Drawing.Point(311, 84);
            this.rroom103.Name = "rroom103";
            this.rroom103.Size = new System.Drawing.Size(78, 42);
            this.rroom103.TabIndex = 2;
            this.rroom103.Text = "103";
            this.rroom103.UseVisualStyleBackColor = false;
            this.rroom103.Click += new System.EventHandler(this.rroom103_Click);
            // 
            // rroom102
            // 
            this.rroom102.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom102.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom102.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom102.Location = new System.Drawing.Point(179, 84);
            this.rroom102.Name = "rroom102";
            this.rroom102.Size = new System.Drawing.Size(78, 42);
            this.rroom102.TabIndex = 1;
            this.rroom102.Text = "102";
            this.rroom102.UseVisualStyleBackColor = false;
            this.rroom102.Click += new System.EventHandler(this.rroom102_Click);
            // 
            // rroom101
            // 
            this.rroom101.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom101.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom101.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom101.Location = new System.Drawing.Point(44, 84);
            this.rroom101.Name = "rroom101";
            this.rroom101.Size = new System.Drawing.Size(78, 42);
            this.rroom101.TabIndex = 0;
            this.rroom101.Text = "101";
            this.rroom101.UseVisualStyleBackColor = false;
            this.rroom101.Click += new System.EventHandler(this.rroom101_Click);
            // 
            // rFree
            // 
            this.rFree.BackColor = System.Drawing.Color.YellowGreen;
            this.rFree.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rFree.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rFree.Location = new System.Drawing.Point(831, 562);
            this.rFree.Name = "rFree";
            this.rFree.Size = new System.Drawing.Size(78, 41);
            this.rFree.TabIndex = 9;
            this.rFree.Text = "Free";
            this.rFree.UseVisualStyleBackColor = false;
            this.rFree.Click += new System.EventHandler(this.rFree_Click);
            // 
            // rfilled
            // 
            this.rfilled.BackColor = System.Drawing.Color.Red;
            this.rfilled.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rfilled.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rfilled.Location = new System.Drawing.Point(923, 562);
            this.rfilled.Name = "rfilled";
            this.rfilled.Size = new System.Drawing.Size(78, 41);
            this.rfilled.TabIndex = 10;
            this.rfilled.Text = "Filled";
            this.rfilled.UseVisualStyleBackColor = false;
            this.rfilled.Click += new System.EventHandler(this.rfilled_Click);
            // 
            // nback
            // 
            this.nback.BackColor = System.Drawing.Color.Transparent;
            this.nback.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nback.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.nback.Location = new System.Drawing.Point(12, 581);
            this.nback.Name = "nback";
            this.nback.Size = new System.Drawing.Size(88, 36);
            this.nback.TabIndex = 42;
            this.nback.Text = "Back";
            this.nback.UseVisualStyleBackColor = false;
            this.nback.Click += new System.EventHandler(this.nback_Click);
            // 
            // NewCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1072, 629);
            this.Controls.Add(this.nback);
            this.Controls.Add(this.rfilled);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.rFree);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NewCustomer";
            this.Text = "Add New Customer";
            this.Load += new System.EventHandler(this.NewCustomer_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button rsave;
        private System.Windows.Forms.DateTimePicker rcheckoutdate;
        private System.Windows.Forms.DateTimePicker rcheckindate;
        private System.Windows.Forms.MaskedTextBox rphone;
        private System.Windows.Forms.TextBox rroomno;
        private System.Windows.Forms.TextBox rnationalid;
        private System.Windows.Forms.TextBox rmail;
        private System.Windows.Forms.TextBox rsurname;
        private System.Windows.Forms.TextBox rname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button rfilled;
        private System.Windows.Forms.Button rFree;
        private System.Windows.Forms.Button rroom109;
        private System.Windows.Forms.Button rroom108;
        private System.Windows.Forms.Button rroom107;
        private System.Windows.Forms.Button rroom106;
        private System.Windows.Forms.Button rroom105;
        private System.Windows.Forms.Button rroom104;
        private System.Windows.Forms.Button rroom103;
        private System.Windows.Forms.Button rroom102;
        private System.Windows.Forms.Button rroom101;
        private System.Windows.Forms.TextBox rtotal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button nback;
    }
}