﻿namespace PansiyonOtomasyonu
{
    partial class adminlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminlogin));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ausername = new System.Windows.Forms.TextBox();
            this.apassowrd = new System.Windows.Forms.TextBox();
            this.alogin = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(147, 249);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(147, 308);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password:";
            // 
            // ausername
            // 
            this.ausername.BackColor = System.Drawing.SystemColors.Info;
            this.ausername.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ausername.Location = new System.Drawing.Point(283, 258);
            this.ausername.Name = "ausername";
            this.ausername.Size = new System.Drawing.Size(144, 25);
            this.ausername.TabIndex = 2;
            this.ausername.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // apassowrd
            // 
            this.apassowrd.BackColor = System.Drawing.SystemColors.Info;
            this.apassowrd.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.apassowrd.Location = new System.Drawing.Point(285, 315);
            this.apassowrd.Name = "apassowrd";
            this.apassowrd.Size = new System.Drawing.Size(144, 25);
            this.apassowrd.TabIndex = 3;
            this.apassowrd.UseSystemPasswordChar = true;
            // 
            // alogin
            // 
            this.alogin.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.alogin.Location = new System.Drawing.Point(283, 371);
            this.alogin.Name = "alogin";
            this.alogin.Size = new System.Drawing.Size(93, 38);
            this.alogin.TabIndex = 4;
            this.alogin.Text = "Login";
            this.alogin.UseVisualStyleBackColor = false;
            this.alogin.Click += new System.EventHandler(this.alogin_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Moccasin;
            this.label3.Location = new System.Drawing.Point(82, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(464, 40);
            this.label3.TabIndex = 5;
            this.label3.Text = "Motel                             Moonlight";
            // 
            // adminlogin
            // 
            this.AcceptButton = this.alogin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(593, 498);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.alogin);
            this.Controls.Add(this.apassowrd);
            this.Controls.Add(this.ausername);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "adminlogin";
            this.Text = "Admin Giris";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ausername;
        private System.Windows.Forms.TextBox apassowrd;
        private System.Windows.Forms.Button alogin;
        private System.Windows.Forms.Label label3;
    }
}

