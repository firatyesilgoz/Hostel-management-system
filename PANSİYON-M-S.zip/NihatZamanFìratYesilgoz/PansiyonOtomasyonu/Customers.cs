﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace PansiyonOtomasyonu
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        //Data Source=DESKTOP-340M9CG;Initial Catalog=MotelMoonlight;Integrated Security=True

        private void showdatas()
        {
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM customer_view1", baglanti);
            SqlDataReader read = cmd.ExecuteReader();   

            while (read.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read["Customer_id"].ToString();
                add.SubItems.Add(read["name"].ToString());
                add.SubItems.Add(read["Surname"].ToString());
                add.SubItems.Add(read["Gender"].ToString());
                add.SubItems.Add(read["Phone"].ToString());
                add.SubItems.Add(read["Mail"].ToString());
                add.SubItems.Add(read["National_id"].ToString());
                add.SubItems.Add(read["room_number"].ToString());
                add.SubItems.Add(read["total"].ToString());
                add.SubItems.Add(read["Check_in_Date"].ToString());
                add.SubItems.Add(read["Check_out_Date"].ToString());

                listView1.Items.Add(add);
            }
            baglanti.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            showdatas();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        int id = 0;

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            id = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
            rname.Text=listView1.SelectedItems[0].SubItems[1].Text;
            rsurname.Text = listView1.SelectedItems[0].SubItems[2].Text;
            comboBox1.Text = listView1.SelectedItems[0].SubItems[3].Text;
            rphone.Text = listView1.SelectedItems[0].SubItems[4].Text;
            rmail.Text = listView1.SelectedItems[0].SubItems[5].Text;
            rnationalid.Text = listView1.SelectedItems[0].SubItems[6].Text;
            rroomno.Text = listView1.SelectedItems[0].SubItems[7].Text;
            rtotal.Text = listView1.SelectedItems[0].SubItems[8].Text;
            rcheckindate.Text = listView1.SelectedItems[0].SubItems[9].Text;
            rcheckoutdate.Text = listView1.SelectedItems[0].SubItems[10].Text;
           
        }
        //
        //SqlCommand cmd = new SqlCommand("delete from add_customer where Customer_id=(" + id + ")", baglanti);
        private void Cdelete_Click(object sender, EventArgs e)
        {
            if (rroomno.Text == "101")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room101", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "102")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room102", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "103")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room103", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "104")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room104", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "105")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room105", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "106")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room106", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "107")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room107", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "108")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room101", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
            if (rroomno.Text == "109")
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand("delete from room109", baglanti);
                cmd.ExecuteNonQuery();
                baglanti.Close();
                showdatas();
            }
        }

        private void Cclear_Click(object sender, EventArgs e)
        {
            rname.Clear();
            rsurname.Clear();
            comboBox1.Text = "";
            rphone.Clear();
            rmail.Clear();
            rnationalid.Clear();
            rroomno.Clear();
            rtotal.Clear();
            rcheckindate.Text = "";
            rcheckoutdate.Text = "";


        }

        private void Cupdate_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("update add_customer1 set Name='"+ rname.Text+"' , Surname='"+rsurname.Text + "' , Gender='" +comboBox1.Text + "' , Phone='" + rphone.Text + "' , Mail='" + rmail.Text + "' , National_id='" + rnationalid.Text + "' , room_number='" + rroomno.Text + "' , total='" + rtotal.Text + "' , Check_in_Date='" + rcheckindate.Value.ToString("yyyy-MM-dd") + "' , Check_out_date='" + rcheckoutdate.Value.ToString("yyyy-MM-dd") + "' where Customer_id=" + id + "", baglanti);
            cmd.ExecuteNonQuery();
            baglanti.Close();
            showdatas();
        }

        private void Csearch_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("select * from add_customer1 where Name like '%"+Csearchbox.Text+"%'", baglanti);
            SqlDataReader read = cmd.ExecuteReader();

            while (read.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read["Customer_id"].ToString();
                add.SubItems.Add(read["Name"].ToString());
                add.SubItems.Add(read["Surname"].ToString());
                add.SubItems.Add(read["Gender"].ToString());
                add.SubItems.Add(read["Phone"].ToString());
                add.SubItems.Add(read["Mail"].ToString());
                add.SubItems.Add(read["National_id"].ToString());
                add.SubItems.Add(read["room_number"].ToString());
                add.SubItems.Add(read["total"].ToString());
                add.SubItems.Add(read["Check_in_Date"].ToString());
                add.SubItems.Add(read["Check_out_date"].ToString());

                listView1.Items.Add(add);
            }
            baglanti.Close();
        }

        private void Customers_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Mainpage fr = new Mainpage();
            fr.Show();
            this.Close();
        }
    }
}
