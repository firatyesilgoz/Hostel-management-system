﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PansiyonOtomasyonu
{
    public partial class adminlogin : Form
    {
        public adminlogin()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void alogin_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                string sql = "select * from adminLogin where username=@Username AND password=@Password";
                SqlParameter prm1 = new SqlParameter("username", ausername.Text.Trim());
                SqlParameter prm2 = new SqlParameter("password", apassowrd.Text.Trim());
                SqlCommand cmd=new SqlCommand(sql,baglanti);
                cmd.Parameters.Add(prm1);
                cmd.Parameters.Add(prm2);
                DataTable dt=new DataTable();
                SqlDataAdapter da=new SqlDataAdapter(cmd);
                da.Fill(dt);

                if(dt.Rows.Count > 0)
                {
                    Mainpage fr=new Mainpage();
                    fr.Show();
                    this.Hide();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect entry");
            }
        }
    }
}
