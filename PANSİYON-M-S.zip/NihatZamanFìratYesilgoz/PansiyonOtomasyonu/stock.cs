﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PansiyonOtomasyonu
{
    public partial class stock : Form
    {
        public stock()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void data()
        {
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("select * from products_received",baglanti);
            SqlDataReader read = cmd.ExecuteReader();
            while (read.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read["Food"].ToString();
                add.SubItems.Add(read["Drinks"].ToString());
                add.SubItems.Add(read["Cookies"].ToString());
                listView1.Items.Add(add);


            }
            baglanti.Close();
        }
        private void data2()
        {
            listView2.Items.Clear();
            baglanti.Open();
            SqlCommand cmd2 = new SqlCommand("select * from bills", baglanti);
            SqlDataReader read2 = cmd2.ExecuteReader();
            while (read2.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read2["Electiricity"].ToString();
                add.SubItems.Add(read2["water"].ToString());
                add.SubItems.Add(read2["Internet"].ToString());
                listView2.Items.Add(add);


            }
            baglanti.Close();
        }
        private void label1_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            SqlCommand cmd = new SqlCommand("insert into bills(Electiricity,water,Internet) values('" + selectricity.Text + "','" + swater.Text + "','" + sinternet.Text + "')", baglanti);
            cmd.ExecuteNonQuery();
            baglanti.Close();
            data2();

        }

        private void ssave_Click(object sender, EventArgs e)
        {
            baglanti.Open();
        
            SqlCommand cmd2 = new SqlCommand("insert into products_received(Food,Drinks,Cookies) values('" + Sfood.Text + "','" + SDrinks.Text + "','" + SCookies.Text + "')", baglanti);

            cmd2.ExecuteNonQuery();
            baglanti.Close();
            data(); 
        }

        private void stock_Load(object sender, EventArgs e)
        {
            data();
            data2();    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mainpage fr = new Mainpage();
            fr.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                baglanti.Open();

                SqlCommand cmd = new SqlCommand("insert into bills(Electiricity,water,Internet) values('" + selectricity.Text + "','" + swater.Text + "','" + sinternet.Text + "')", baglanti);

                cmd.ExecuteNonQuery();
                baglanti.Close();
                data2();
            }
        }
    }
}
