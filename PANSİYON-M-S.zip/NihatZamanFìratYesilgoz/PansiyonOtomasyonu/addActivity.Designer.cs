﻿namespace PansiyonOtomasyonu
{
    partial class addActivity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addActivity));
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Cclear = new System.Windows.Forms.Button();
            this.Cdelete = new System.Windows.Forms.Button();
            this.Cupdate = new System.Windows.Forms.Button();
            this.CShowData = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(42, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(328, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Activity Price:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(423, 74);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(144, 20);
            this.textBox2.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(39, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Activity Name:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(134, 71);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(144, 20);
            this.textBox1.TabIndex = 8;
            // 
            // Cclear
            // 
            this.Cclear.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cclear.ForeColor = System.Drawing.Color.Black;
            this.Cclear.Location = new System.Drawing.Point(409, 426);
            this.Cclear.Name = "Cclear";
            this.Cclear.Size = new System.Drawing.Size(158, 36);
            this.Cclear.TabIndex = 67;
            this.Cclear.Text = "Clear";
            this.Cclear.UseVisualStyleBackColor = false;
            this.Cclear.Click += new System.EventHandler(this.Cclear_Click);
            // 
            // Cdelete
            // 
            this.Cdelete.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cdelete.ForeColor = System.Drawing.Color.Black;
            this.Cdelete.Location = new System.Drawing.Point(224, 460);
            this.Cdelete.Name = "Cdelete";
            this.Cdelete.Size = new System.Drawing.Size(158, 37);
            this.Cdelete.TabIndex = 66;
            this.Cdelete.Text = "Delete";
            this.Cdelete.UseVisualStyleBackColor = false;
            // 
            // Cupdate
            // 
            this.Cupdate.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cupdate.ForeColor = System.Drawing.Color.Black;
            this.Cupdate.Location = new System.Drawing.Point(42, 459);
            this.Cupdate.Name = "Cupdate";
            this.Cupdate.Size = new System.Drawing.Size(158, 37);
            this.Cupdate.TabIndex = 65;
            this.Cupdate.Text = "Update";
            this.Cupdate.UseVisualStyleBackColor = false;
            // 
            // CShowData
            // 
            this.CShowData.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CShowData.ForeColor = System.Drawing.Color.Black;
            this.CShowData.Location = new System.Drawing.Point(42, 399);
            this.CShowData.Name = "CShowData";
            this.CShowData.Size = new System.Drawing.Size(158, 37);
            this.CShowData.TabIndex = 64;
            this.CShowData.Text = "Show Data";
            this.CShowData.UseVisualStyleBackColor = false;
            this.CShowData.Click += new System.EventHandler(this.CShowData_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(224, 399);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(158, 37);
            this.button2.TabIndex = 68;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(42, 145);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(541, 226);
            this.listView1.TabIndex = 69;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 63;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Name";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 109;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Price";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 399;
            // 
            // addActivity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(617, 525);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Cclear);
            this.Controls.Add(this.Cdelete);
            this.Controls.Add(this.Cupdate);
            this.Controls.Add(this.CShowData);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "addActivity";
            this.Text = "addActivity";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Cclear;
        private System.Windows.Forms.Button Cdelete;
        private System.Windows.Forms.Button Cupdate;
        private System.Windows.Forms.Button CShowData;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}