﻿namespace PansiyonOtomasyonu
{
    partial class employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(employee));
            this.button1 = new System.Windows.Forms.Button();
            this.Cclear = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.rphone = new System.Windows.Forms.MaskedTextBox();
            this.rmail = new System.Windows.Forms.TextBox();
            this.rsurname = new System.Windows.Forms.TextBox();
            this.rname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Cdelete = new System.Windows.Forms.Button();
            this.Cupdate = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CShowData = new System.Windows.Forms.Button();
            this.enati = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(54, 553);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 37);
            this.button1.TabIndex = 81;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Cclear
            // 
            this.Cclear.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cclear.ForeColor = System.Drawing.Color.Black;
            this.Cclear.Location = new System.Drawing.Point(376, 263);
            this.Cclear.Name = "Cclear";
            this.Cclear.Size = new System.Drawing.Size(257, 46);
            this.Cclear.TabIndex = 80;
            this.Cclear.Text = "Clear";
            this.Cclear.UseVisualStyleBackColor = false;
            this.Cclear.Click += new System.EventHandler(this.Cclear_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Man",
            "Women"});
            this.comboBox1.Location = new System.Drawing.Point(216, 127);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(134, 21);
            this.comboBox1.TabIndex = 79;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(49, 117);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 30);
            this.label10.TabIndex = 78;
            this.label10.Text = "Gender :";
            // 
            // rphone
            // 
            this.rphone.Location = new System.Drawing.Point(216, 167);
            this.rphone.Mask = "(999) 000-0000";
            this.rphone.Name = "rphone";
            this.rphone.Size = new System.Drawing.Size(134, 20);
            this.rphone.TabIndex = 77;
            // 
            // rmail
            // 
            this.rmail.Location = new System.Drawing.Point(216, 207);
            this.rmail.Name = "rmail";
            this.rmail.Size = new System.Drawing.Size(134, 20);
            this.rmail.TabIndex = 76;
            // 
            // rsurname
            // 
            this.rsurname.Location = new System.Drawing.Point(216, 87);
            this.rsurname.Name = "rsurname";
            this.rsurname.Size = new System.Drawing.Size(134, 20);
            this.rsurname.TabIndex = 75;
            // 
            // rname
            // 
            this.rname.Location = new System.Drawing.Point(216, 47);
            this.rname.Name = "rname";
            this.rname.Size = new System.Drawing.Size(134, 20);
            this.rname.TabIndex = 74;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(49, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 30);
            this.label5.TabIndex = 73;
            this.label5.Text = "National ID :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(49, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 30);
            this.label4.TabIndex = 72;
            this.label4.Text = "Mail :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(49, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 30);
            this.label3.TabIndex = 71;
            this.label3.Text = "Phone :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(49, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 30);
            this.label2.TabIndex = 70;
            this.label2.Text = "Surname :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(49, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 30);
            this.label1.TabIndex = 69;
            this.label1.Text = "Name :";
            // 
            // Cdelete
            // 
            this.Cdelete.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cdelete.ForeColor = System.Drawing.Color.Black;
            this.Cdelete.Location = new System.Drawing.Point(432, 207);
            this.Cdelete.Name = "Cdelete";
            this.Cdelete.Size = new System.Drawing.Size(158, 37);
            this.Cdelete.TabIndex = 68;
            this.Cdelete.Text = "Delete";
            this.Cdelete.UseVisualStyleBackColor = false;
            // 
            // Cupdate
            // 
            this.Cupdate.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cupdate.ForeColor = System.Drawing.Color.Black;
            this.Cupdate.Location = new System.Drawing.Point(432, 151);
            this.Cupdate.Name = "Cupdate";
            this.Cupdate.Size = new System.Drawing.Size(158, 37);
            this.Cupdate.TabIndex = 67;
            this.Cupdate.Text = "Update";
            this.Cupdate.UseVisualStyleBackColor = false;
            this.Cupdate.Click += new System.EventHandler(this.Cupdate_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(38, 328);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(595, 219);
            this.listView1.TabIndex = 66;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "id";
            this.columnHeader1.Width = 52;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "name";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "surname";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "gender";
            this.columnHeader4.Width = 115;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "phone";
            this.columnHeader5.Width = 121;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "mail";
            this.columnHeader6.Width = 70;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "national id";
            this.columnHeader7.Width = 105;
            // 
            // CShowData
            // 
            this.CShowData.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CShowData.ForeColor = System.Drawing.Color.Black;
            this.CShowData.Location = new System.Drawing.Point(432, 96);
            this.CShowData.Name = "CShowData";
            this.CShowData.Size = new System.Drawing.Size(158, 37);
            this.CShowData.TabIndex = 65;
            this.CShowData.Text = "Show Data";
            this.CShowData.UseVisualStyleBackColor = false;
            this.CShowData.Click += new System.EventHandler(this.CShowData_Click);
            // 
            // enati
            // 
            this.enati.Location = new System.Drawing.Point(216, 250);
            this.enati.Name = "enati";
            this.enati.Size = new System.Drawing.Size(134, 20);
            this.enati.TabIndex = 82;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(432, 38);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(158, 37);
            this.button2.TabIndex = 83;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(722, 642);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.enati);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Cclear);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.rphone);
            this.Controls.Add(this.rmail);
            this.Controls.Add(this.rsurname);
            this.Controls.Add(this.rname);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Cdelete);
            this.Controls.Add(this.Cupdate);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.CShowData);
            this.Name = "employee";
            this.Text = "employee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Cclear;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MaskedTextBox rphone;
        private System.Windows.Forms.TextBox rmail;
        private System.Windows.Forms.TextBox rsurname;
        private System.Windows.Forms.TextBox rname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Cdelete;
        private System.Windows.Forms.Button Cupdate;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Button CShowData;
        private System.Windows.Forms.TextBox enati;
        private System.Windows.Forms.Button button2;
    }
}