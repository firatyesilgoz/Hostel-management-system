﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PansiyonOtomasyonu
{
    public partial class employee : Form
    {
        public employee()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void showdatas()
        {
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("select * from employee", baglanti);
            SqlDataReader read = cmd.ExecuteReader();

            while (read.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read["employe_id"].ToString();
                add.SubItems.Add(read["name"].ToString());
                add.SubItems.Add(read["Surname"].ToString());
                add.SubItems.Add(read["Gender"].ToString());
                add.SubItems.Add(read["Phone"].ToString());
                add.SubItems.Add(read["Mail"].ToString());
                add.SubItems.Add(read["National_id"].ToString());
                

                listView1.Items.Add(add);
            }
            baglanti.Close();
        }
        
        int id = 0;

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            id = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
            rname.Text = listView1.SelectedItems[0].SubItems[1].Text;
            rsurname.Text = listView1.SelectedItems[0].SubItems[2].Text;
            comboBox1.Text = listView1.SelectedItems[0].SubItems[3].Text;
            rphone.Text = listView1.SelectedItems[0].SubItems[4].Text;
            rmail.Text = listView1.SelectedItems[0].SubItems[5].Text;
            enati.Text = listView1.SelectedItems[0].SubItems[6].Text;
            

        }
        private void Cupdate_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("update employee set name='" + rname.Text + "' , Surname='" + rsurname.Text + "' , Gender='" + comboBox1.Text + "' , Phone='" + rphone.Text + "' , Mail='" + rmail.Text + "' , National_id='" + enati.Text + "' where employe_id=" + id + "", baglanti);
            cmd.ExecuteNonQuery();
            baglanti.Close();
            showdatas();
        }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CShowData_Click(object sender, EventArgs e)
        {
            showdatas();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            // SqlCommand komut = new SqlCommand("insert into employee (name,Surname,Gender,Phone,Mail,National_id) values('" + rname.Text + "','" + rsurname.Text + "','" + comboBox1.Text + "','" + rphone.Text + "','" + rmail.Text + "','" + enati.Text  + "')", baglanti);
            //  komut.ExecuteNonQuery();
            string query = "INSERT INTO employee (name,Surname,Gender,Phone,Mail,National_id) values (@name, @Surname, @Gender, @Phone, @Mail, @National_id)";
            using (SqlCommand command = new SqlCommand(query, baglanti))
            {
                command.Parameters.AddWithValue("@name",rname.Text);
                command.Parameters.AddWithValue("@surname", rsurname.Text);
                command.Parameters.AddWithValue("@gender", comboBox1.Text);
                command.Parameters.AddWithValue("@phone", rphone.Text);
                command.Parameters.AddWithValue("@mail", rmail.Text);
                command.Parameters.AddWithValue("@national_id", enati.Text);

                command.ExecuteNonQuery();
            }
            baglanti.Close();
            
            
        }

        private void Cclear_Click(object sender, EventArgs e)
        {
            rname.Clear();
            rsurname.Clear();
            comboBox1.Text = "";
            rphone.Clear();
            rmail.Clear();
            enati.Clear();
            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mainpage fr = new Mainpage();
            fr.Show();
            this.Close();
        }
    }
}
