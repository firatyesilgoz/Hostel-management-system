﻿namespace PansiyonOtomasyonu
{
    partial class incomeexpense
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(incomeexpense));
            this.itotal = new System.Windows.Forms.Label();
            this.Itotalsafe = new System.Windows.Forms.Label();
            this.Istaff = new System.Windows.Forms.Label();
            this.isalaries = new System.Windows.Forms.Label();
            this.ifood = new System.Windows.Forms.Label();
            this.iproductsreceived = new System.Windows.Forms.Label();
            this.ielectricity = new System.Windows.Forms.Label();
            this.ibill = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.personal = new System.Windows.Forms.TextBox();
            this.Icalculate = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.idrink = new System.Windows.Forms.Label();
            this.icookies = new System.Windows.Forms.Label();
            this.iresult = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.iwater = new System.Windows.Forms.Label();
            this.iinternet = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // itotal
            // 
            this.itotal.BackColor = System.Drawing.Color.Transparent;
            this.itotal.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.itotal.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.itotal.Location = new System.Drawing.Point(92, 53);
            this.itotal.Name = "itotal";
            this.itotal.Size = new System.Drawing.Size(236, 38);
            this.itotal.TabIndex = 0;
            this.itotal.Text = "Total amount in the safe :";
            // 
            // Itotalsafe
            // 
            this.Itotalsafe.BackColor = System.Drawing.Color.Transparent;
            this.Itotalsafe.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Itotalsafe.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Itotalsafe.Location = new System.Drawing.Point(334, 53);
            this.Itotalsafe.Name = "Itotalsafe";
            this.Itotalsafe.Size = new System.Drawing.Size(82, 38);
            this.Itotalsafe.TabIndex = 1;
            this.Itotalsafe.Text = "00";
            // 
            // Istaff
            // 
            this.Istaff.BackColor = System.Drawing.Color.Transparent;
            this.Istaff.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Istaff.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Istaff.Location = new System.Drawing.Point(334, 114);
            this.Istaff.Name = "Istaff";
            this.Istaff.Size = new System.Drawing.Size(82, 43);
            this.Istaff.TabIndex = 3;
            this.Istaff.Text = "00";
            // 
            // isalaries
            // 
            this.isalaries.BackColor = System.Drawing.Color.Transparent;
            this.isalaries.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.isalaries.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.isalaries.Location = new System.Drawing.Point(92, 114);
            this.isalaries.Name = "isalaries";
            this.isalaries.Size = new System.Drawing.Size(236, 43);
            this.isalaries.TabIndex = 2;
            this.isalaries.Text = "         Staff Salaries :";
            // 
            // ifood
            // 
            this.ifood.BackColor = System.Drawing.Color.Transparent;
            this.ifood.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ifood.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ifood.Location = new System.Drawing.Point(334, 175);
            this.ifood.Name = "ifood";
            this.ifood.Size = new System.Drawing.Size(82, 40);
            this.ifood.TabIndex = 5;
            this.ifood.Text = "00";
            // 
            // iproductsreceived
            // 
            this.iproductsreceived.BackColor = System.Drawing.Color.Transparent;
            this.iproductsreceived.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.iproductsreceived.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.iproductsreceived.Location = new System.Drawing.Point(92, 175);
            this.iproductsreceived.Name = "iproductsreceived";
            this.iproductsreceived.Size = new System.Drawing.Size(236, 40);
            this.iproductsreceived.TabIndex = 4;
            this.iproductsreceived.Text = "Total of products received :";
            // 
            // ielectricity
            // 
            this.ielectricity.BackColor = System.Drawing.Color.Transparent;
            this.ielectricity.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ielectricity.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ielectricity.Location = new System.Drawing.Point(334, 233);
            this.ielectricity.Name = "ielectricity";
            this.ielectricity.Size = new System.Drawing.Size(82, 43);
            this.ielectricity.TabIndex = 7;
            this.ielectricity.Text = "00";
            this.ielectricity.Click += new System.EventHandler(this.Ibills_Click);
            // 
            // ibill
            // 
            this.ibill.BackColor = System.Drawing.Color.Transparent;
            this.ibill.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ibill.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ibill.Location = new System.Drawing.Point(92, 233);
            this.ibill.Name = "ibill";
            this.ibill.Size = new System.Drawing.Size(236, 43);
            this.ibill.TabIndex = 6;
            this.ibill.Text = "                    Bills :";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(488, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(172, 38);
            this.label9.TabIndex = 8;
            this.label9.Text = "Personal Number :";
            // 
            // personal
            // 
            this.personal.Location = new System.Drawing.Point(666, 33);
            this.personal.Multiline = true;
            this.personal.Name = "personal";
            this.personal.Size = new System.Drawing.Size(81, 26);
            this.personal.TabIndex = 9;
            this.personal.TextChanged += new System.EventHandler(this.Ipersonelno_TextChanged);
            // 
            // Icalculate
            // 
            this.Icalculate.Location = new System.Drawing.Point(493, 319);
            this.Icalculate.Name = "Icalculate";
            this.Icalculate.Size = new System.Drawing.Size(169, 39);
            this.Icalculate.TabIndex = 10;
            this.Icalculate.Text = "Calculate";
            this.Icalculate.UseVisualStyleBackColor = true;
            this.Icalculate.Click += new System.EventHandler(this.Icalculate_Click);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Location = new System.Drawing.Point(4, 276);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(784, 43);
            this.label12.TabIndex = 13;
            this.label12.Text = "---------------------------------------------------------------------------------" +
    "-----------------";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // idrink
            // 
            this.idrink.BackColor = System.Drawing.Color.Transparent;
            this.idrink.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.idrink.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.idrink.Location = new System.Drawing.Point(392, 175);
            this.idrink.Name = "idrink";
            this.idrink.Size = new System.Drawing.Size(82, 40);
            this.idrink.TabIndex = 14;
            this.idrink.Text = "00";
            // 
            // icookies
            // 
            this.icookies.BackColor = System.Drawing.Color.Transparent;
            this.icookies.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.icookies.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.icookies.Location = new System.Drawing.Point(454, 175);
            this.icookies.Name = "icookies";
            this.icookies.Size = new System.Drawing.Size(82, 40);
            this.icookies.TabIndex = 15;
            this.icookies.Text = "00";
            this.icookies.Click += new System.EventHandler(this.icookies_Click);
            // 
            // iresult
            // 
            this.iresult.BackColor = System.Drawing.Color.Transparent;
            this.iresult.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.iresult.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.iresult.Location = new System.Drawing.Point(92, 319);
            this.iresult.Name = "iresult";
            this.iresult.Size = new System.Drawing.Size(236, 43);
            this.iresult.TabIndex = 11;
            this.iresult.Text = "                 Result:";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(334, 319);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 26);
            this.label7.TabIndex = 12;
            this.label7.Text = "00";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // iwater
            // 
            this.iwater.BackColor = System.Drawing.Color.Transparent;
            this.iwater.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.iwater.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.iwater.Location = new System.Drawing.Point(392, 233);
            this.iwater.Name = "iwater";
            this.iwater.Size = new System.Drawing.Size(82, 43);
            this.iwater.TabIndex = 16;
            this.iwater.Text = "00";
            // 
            // iinternet
            // 
            this.iinternet.BackColor = System.Drawing.Color.Transparent;
            this.iinternet.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.iinternet.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.iinternet.Location = new System.Drawing.Point(454, 233);
            this.iinternet.Name = "iinternet";
            this.iinternet.Size = new System.Drawing.Size(82, 43);
            this.iinternet.TabIndex = 17;
            this.iinternet.Text = "00";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 371);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 39);
            this.button1.TabIndex = 18;
            this.button1.Text = "iback";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(672, 89);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "getEmployees";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // incomeexpense
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 432);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.iinternet);
            this.Controls.Add(this.iwater);
            this.Controls.Add(this.icookies);
            this.Controls.Add(this.idrink);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.iresult);
            this.Controls.Add(this.Icalculate);
            this.Controls.Add(this.personal);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.ielectricity);
            this.Controls.Add(this.ibill);
            this.Controls.Add(this.ifood);
            this.Controls.Add(this.iproductsreceived);
            this.Controls.Add(this.Istaff);
            this.Controls.Add(this.isalaries);
            this.Controls.Add(this.Itotalsafe);
            this.Controls.Add(this.itotal);
            this.Name = "incomeexpense";
            this.Text = "incomeexpense";
            this.Load += new System.EventHandler(this.incomeexpense_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label itotal;
        private System.Windows.Forms.Label Itotalsafe;
        private System.Windows.Forms.Label Istaff;
        private System.Windows.Forms.Label isalaries;
        private System.Windows.Forms.Label ifood;
        private System.Windows.Forms.Label iproductsreceived;
        private System.Windows.Forms.Label ielectricity;
        private System.Windows.Forms.Label ibill;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox personal;
        private System.Windows.Forms.Button Icalculate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label idrink;
        private System.Windows.Forms.Label icookies;
        private System.Windows.Forms.Label iresult;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label iwater;
        private System.Windows.Forms.Label iinternet;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}