﻿namespace PansiyonOtomasyonu
{
    partial class Mainpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mainpage));
            this.Mnewcustomer = new System.Windows.Forms.Button();
            this.Mrooms = new System.Windows.Forms.Button();
            this.Mcustomers = new System.Windows.Forms.Button();
            this.MEployeessalary = new System.Windows.Forms.Button();
            this.Mstocktable = new System.Windows.Forms.Button();
            this.MCustomerspu = new System.Windows.Forms.Button();
            this.Mwatchtv = new System.Windows.Forms.Button();
            this.Maboutus = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Mexit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Mnewcustomer
            // 
            this.Mnewcustomer.Location = new System.Drawing.Point(79, 44);
            this.Mnewcustomer.Name = "Mnewcustomer";
            this.Mnewcustomer.Size = new System.Drawing.Size(109, 53);
            this.Mnewcustomer.TabIndex = 1;
            this.Mnewcustomer.Text = "New Customer";
            this.Mnewcustomer.UseVisualStyleBackColor = true;
            this.Mnewcustomer.Click += new System.EventHandler(this.button1_Click);
            // 
            // Mrooms
            // 
            this.Mrooms.Location = new System.Drawing.Point(205, 44);
            this.Mrooms.Name = "Mrooms";
            this.Mrooms.Size = new System.Drawing.Size(115, 53);
            this.Mrooms.TabIndex = 2;
            this.Mrooms.Text = "Rooms";
            this.Mrooms.UseVisualStyleBackColor = true;
            this.Mrooms.Click += new System.EventHandler(this.Mrooms_Click);
            // 
            // Mcustomers
            // 
            this.Mcustomers.Location = new System.Drawing.Point(74, 146);
            this.Mcustomers.Name = "Mcustomers";
            this.Mcustomers.Size = new System.Drawing.Size(112, 53);
            this.Mcustomers.TabIndex = 3;
            this.Mcustomers.Text = "Customers";
            this.Mcustomers.UseVisualStyleBackColor = true;
            this.Mcustomers.Click += new System.EventHandler(this.button3_Click);
            // 
            // MEployeessalary
            // 
            this.MEployeessalary.Location = new System.Drawing.Point(211, 146);
            this.MEployeessalary.Name = "MEployeessalary";
            this.MEployeessalary.Size = new System.Drawing.Size(109, 53);
            this.MEployeessalary.TabIndex = 4;
            this.MEployeessalary.Text = "Income-Expense";
            this.MEployeessalary.UseVisualStyleBackColor = true;
            this.MEployeessalary.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Mstocktable
            // 
            this.Mstocktable.Location = new System.Drawing.Point(337, 146);
            this.Mstocktable.Name = "Mstocktable";
            this.Mstocktable.Size = new System.Drawing.Size(115, 53);
            this.Mstocktable.TabIndex = 5;
            this.Mstocktable.Text = "Stock Table";
            this.Mstocktable.UseVisualStyleBackColor = true;
            this.Mstocktable.Click += new System.EventHandler(this.Mstocktable_Click);
            // 
            // MCustomerspu
            // 
            this.MCustomerspu.Location = new System.Drawing.Point(74, 259);
            this.MCustomerspu.Name = "MCustomerspu";
            this.MCustomerspu.Size = new System.Drawing.Size(112, 53);
            this.MCustomerspu.TabIndex = 6;
            this.MCustomerspu.Text = "Customer Support";
            this.MCustomerspu.UseVisualStyleBackColor = true;
            this.MCustomerspu.Click += new System.EventHandler(this.MCustomerspu_Click);
            // 
            // Mwatchtv
            // 
            this.Mwatchtv.Location = new System.Drawing.Point(211, 259);
            this.Mwatchtv.Name = "Mwatchtv";
            this.Mwatchtv.Size = new System.Drawing.Size(109, 53);
            this.Mwatchtv.TabIndex = 7;
            this.Mwatchtv.Text = "Watch TV";
            this.Mwatchtv.UseVisualStyleBackColor = true;
            this.Mwatchtv.Click += new System.EventHandler(this.Mwatchtv_Click);
            // 
            // Maboutus
            // 
            this.Maboutus.Location = new System.Drawing.Point(337, 259);
            this.Maboutus.Name = "Maboutus";
            this.Maboutus.Size = new System.Drawing.Size(115, 53);
            this.Maboutus.TabIndex = 8;
            this.Maboutus.Text = "About us";
            this.Maboutus.UseVisualStyleBackColor = true;
            this.Maboutus.Click += new System.EventHandler(this.button5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.LightSalmon;
            this.label1.Location = new System.Drawing.Point(464, 232);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 21);
            this.label1.TabIndex = 9;
            this.label1.Text = "Date/Month/Years";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.LightSalmon;
            this.label2.Location = new System.Drawing.Point(508, 273);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 21);
            this.label2.TabIndex = 10;
            this.label2.Text = "Hour";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Mexit
            // 
            this.Mexit.Location = new System.Drawing.Point(484, 146);
            this.Mexit.Name = "Mexit";
            this.Mexit.Size = new System.Drawing.Size(115, 53);
            this.Mexit.TabIndex = 13;
            this.Mexit.Text = "Exit";
            this.Mexit.UseVisualStyleBackColor = true;
            this.Mexit.Click += new System.EventHandler(this.button6_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(484, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 53);
            this.button1.TabIndex = 14;
            this.button1.Text = "Activity";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(337, 44);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 53);
            this.button2.TabIndex = 15;
            this.button2.Text = "Employee";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Mainpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(658, 391);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Mexit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Maboutus);
            this.Controls.Add(this.Mwatchtv);
            this.Controls.Add(this.MCustomerspu);
            this.Controls.Add(this.Mstocktable);
            this.Controls.Add(this.MEployeessalary);
            this.Controls.Add(this.Mcustomers);
            this.Controls.Add(this.Mrooms);
            this.Controls.Add(this.Mnewcustomer);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Mainpage";
            this.Text = "Mainpage";
            this.Load += new System.EventHandler(this.Mainpage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Mnewcustomer;
        private System.Windows.Forms.Button Mrooms;
        private System.Windows.Forms.Button Mcustomers;
        private System.Windows.Forms.Button MEployeessalary;
        private System.Windows.Forms.Button Mstocktable;
        private System.Windows.Forms.Button MCustomerspu;
        private System.Windows.Forms.Button Mwatchtv;
        private System.Windows.Forms.Button Maboutus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button Mexit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}