﻿namespace PansiyonOtomasyonu
{
    partial class CustomerMainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerMainPage));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Mexit = new System.Windows.Forms.Button();
            this.Mnewspaper = new System.Windows.Forms.Button();
            this.MweatherForecast = new System.Windows.Forms.Button();
            this.Maboutus = new System.Windows.Forms.Button();
            this.Mwatchtv = new System.Windows.Forms.Button();
            this.MCustomerspu = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.LightSalmon;
            this.label2.Location = new System.Drawing.Point(481, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 21);
            this.label2.TabIndex = 12;
            this.label2.Text = "Hour";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.LightSalmon;
            this.label1.Location = new System.Drawing.Point(435, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 21);
            this.label1.TabIndex = 11;
            this.label1.Text = "Date/Month/Years";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Mexit
            // 
            this.Mexit.Location = new System.Drawing.Point(449, 291);
            this.Mexit.Name = "Mexit";
            this.Mexit.Size = new System.Drawing.Size(115, 53);
            this.Mexit.TabIndex = 19;
            this.Mexit.Text = "Exit";
            this.Mexit.UseVisualStyleBackColor = true;
            this.Mexit.Click += new System.EventHandler(this.Mexit_Click);
            // 
            // Mnewspaper
            // 
            this.Mnewspaper.Location = new System.Drawing.Point(273, 60);
            this.Mnewspaper.Name = "Mnewspaper";
            this.Mnewspaper.Size = new System.Drawing.Size(115, 53);
            this.Mnewspaper.TabIndex = 18;
            this.Mnewspaper.Text = "Newspaper";
            this.Mnewspaper.UseVisualStyleBackColor = true;
            this.Mnewspaper.Click += new System.EventHandler(this.Mnewspaper_Click);
            // 
            // MweatherForecast
            // 
            this.MweatherForecast.Location = new System.Drawing.Point(65, 172);
            this.MweatherForecast.Name = "MweatherForecast";
            this.MweatherForecast.Size = new System.Drawing.Size(115, 53);
            this.MweatherForecast.TabIndex = 17;
            this.MweatherForecast.Text = "Contact";
            this.MweatherForecast.UseVisualStyleBackColor = true;
            this.MweatherForecast.Click += new System.EventHandler(this.MweatherForecast_Click);
            // 
            // Maboutus
            // 
            this.Maboutus.Location = new System.Drawing.Point(273, 291);
            this.Maboutus.Name = "Maboutus";
            this.Maboutus.Size = new System.Drawing.Size(115, 53);
            this.Maboutus.TabIndex = 16;
            this.Maboutus.Text = "About us";
            this.Maboutus.UseVisualStyleBackColor = true;
            this.Maboutus.Click += new System.EventHandler(this.Maboutus_Click);
            // 
            // Mwatchtv
            // 
            this.Mwatchtv.Location = new System.Drawing.Point(71, 60);
            this.Mwatchtv.Name = "Mwatchtv";
            this.Mwatchtv.Size = new System.Drawing.Size(109, 53);
            this.Mwatchtv.TabIndex = 15;
            this.Mwatchtv.Text = "Watch TV";
            this.Mwatchtv.UseVisualStyleBackColor = true;
            this.Mwatchtv.Click += new System.EventHandler(this.Mwatchtv_Click);
            // 
            // MCustomerspu
            // 
            this.MCustomerspu.Location = new System.Drawing.Point(68, 291);
            this.MCustomerspu.Name = "MCustomerspu";
            this.MCustomerspu.Size = new System.Drawing.Size(112, 53);
            this.MCustomerspu.TabIndex = 14;
            this.MCustomerspu.Text = "Customer Support";
            this.MCustomerspu.UseVisualStyleBackColor = true;
            this.MCustomerspu.Click += new System.EventHandler(this.MCustomerspu_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(273, 172);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 53);
            this.button1.TabIndex = 20;
            this.button1.Text = "Activity Page";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(455, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 32);
            this.label3.TabIndex = 21;
            this.label3.Text = "Motel Moonlight";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // CustomerMainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(728, 393);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Mexit);
            this.Controls.Add(this.Mnewspaper);
            this.Controls.Add(this.MweatherForecast);
            this.Controls.Add(this.Maboutus);
            this.Controls.Add(this.Mwatchtv);
            this.Controls.Add(this.MCustomerspu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CustomerMainPage";
            this.Text = "CustomerMainPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Mexit;
        private System.Windows.Forms.Button Mnewspaper;
        private System.Windows.Forms.Button MweatherForecast;
        private System.Windows.Forms.Button Maboutus;
        private System.Windows.Forms.Button Mwatchtv;
        private System.Windows.Forms.Button MCustomerspu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
    }
}