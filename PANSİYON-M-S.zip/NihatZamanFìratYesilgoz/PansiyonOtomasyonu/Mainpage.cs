﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
namespace PansiyonOtomasyonu
{
    public partial class Mainpage : Form
    {
        public Mainpage()
        {
            InitializeComponent();
        }

        private void Madmin_Click(object sender, EventArgs e)
        {
            adminlogin fr = new adminlogin() ;
            fr.Show();
            this.Close();



        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewCustomer fr =new NewCustomer() ;
            fr.Show();
            this.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Customers fr = new Customers() ;
            fr .Show   ();
            this.Close();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            incomeexpense expense = new incomeexpense() ;
            expense.Show();
            this.Close();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("We are  our customers be careful when you decide to stay our motel");
          
        }

        private void Mrooms_Click(object sender, EventArgs e)
        {
            Rooms rm = new Rooms();
            rm.Show();
            this.Close();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Mainpage_Load(object sender, EventArgs e)
        {
            timer1.Start(); 

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongDateString();
            label2.Text = DateTime.Now.ToLongTimeString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Mstocktable_Click(object sender, EventArgs e)
        {
            stock stock = new stock() ;
            stock.Show();
            this.Close();

        }

        private void Mnewspaper_Click(object sender, EventArgs e)
        {
            Newspaper newspaper = new Newspaper() ;
            newspaper.Show();

        }

        private void MCustomerspu_Click(object sender, EventArgs e)
        {
            Customer_Support support = new Customer_Support() ;
            support.Show();
            this.Close();
            

        }

        private void Mwatchtv_Click(object sender, EventArgs e)
        {
            string exeFileAndLocation = @"C:\Users\Nihat\Desktop\sfvip-player-64bit-1.2.3.9\SFVIP-Player-x64\sfvipplayer.exe";
            string arguments = "sampleArgument";
            System.Diagnostics.Process.Start(exeFileAndLocation, arguments);
            
        }

        private void MweatherForecast_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            addActivity fr = new addActivity();
            fr.Show();
            this.Hide   ();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            employee fr = new employee() ;
            fr.Show();
            this.Hide();
        }
    }
}
