﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Security;

namespace PansiyonOtomasyonu
{
    public partial class incomeexpense : Form
    {
        public incomeexpense()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Icalculate_Click(object sender, EventArgs e)
        {
            int personel;
            personel = Convert.ToInt16(personal.Text);
            Istaff.Text = (personel * 2000).ToString();

            int result = Convert.ToInt32(Itotalsafe.Text) -( Convert.ToInt32(Istaff.Text) + Convert.ToInt32(ifood.Text) + Convert.ToInt32(idrink.Text) + Convert.ToInt32(icookies.Text) + Convert.ToInt32(ielectricity.Text) + Convert.ToInt32(iwater.Text) + Convert.ToInt32(iinternet.Text));
            label7.Text = result.ToString();

        }
        
        private void incomeexpense_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("Select sum(total) as Total from add_customer1", baglanti);
            SqlDataReader read = cmd.ExecuteReader();
            while (read.Read())
            {
                Itotalsafe.Text = read["Total"].ToString();

            }
            baglanti.Close();


            baglanti.Open();
            SqlCommand cmd2 = new SqlCommand("Select sum(Food) as total1 from products_received", baglanti);
            SqlDataReader read2 = cmd2.ExecuteReader();
            while (read2.Read())
            {
               ifood.Text = read2["total1"].ToString();

            }
            baglanti.Close();

            baglanti.Open();
            SqlCommand cmd3 = new SqlCommand("Select sum(Drinks) as total2 from products_received", baglanti);
            SqlDataReader read3 = cmd3.ExecuteReader();
            while (read3.Read())
            {
                idrink.Text = read3["total2"].ToString();

            }
            baglanti.Close();

            baglanti.Open();
            SqlCommand cmd4 = new SqlCommand("Select sum(Cookies) as total3 from products_received", baglanti);
            SqlDataReader read4 = cmd4.ExecuteReader();
            while (read4.Read())
            {
                icookies.Text = read4["total3"].ToString();

            }
            baglanti.Close();

            baglanti.Open();
            SqlCommand cmd5 = new SqlCommand("Select sum(Electiricity) as total4 from bills", baglanti);
            SqlDataReader read5 = cmd5.ExecuteReader();
            while (read5.Read())
            {
                ielectricity.Text = read5["total4"].ToString();

            }
            baglanti.Close();


            baglanti.Open();
            SqlCommand cmd6 = new SqlCommand("Select sum(water) as total5 from bills", baglanti);
            SqlDataReader read6 = cmd6.ExecuteReader();
            while (read6.Read())
            {
                iwater.Text = read6["total5"].ToString();

            }
            baglanti.Close();


            baglanti.Open();
            SqlCommand cmd7 = new SqlCommand("Select sum(Internet) as total6 from bills", baglanti);
            SqlDataReader read7 = cmd7.ExecuteReader();
            while (read7.Read())
            {
                iinternet.Text = read7["total6"].ToString();

            }
            baglanti.Close();



        }

        private void Ibills_Click(object sender, EventArgs e)
        {

        }

        private void icookies_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mainpage fr = new Mainpage();
            fr.Show();
            this.Close();
        }

        private void Ipersonelno_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
             baglanti.Open();

            using (SqlCommand command = new SqlCommand("getTotalUserCount", baglanti))
            {
                command.CommandType = CommandType.StoredProcedure;

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int totalUsers = reader.GetInt32(0);
                        personal.Text = totalUsers.ToString();
                        
                    }
                }
            }


        }
    }
}
