﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PansiyonOtomasyonu
{
    public partial class CustomerMainPage : Form
    {
        public CustomerMainPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Activity fr=new Activity();
            fr.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void MweatherForecast_Click(object sender, EventArgs e)
        {
            Contact fr = new Contact();
            this.Hide();
            fr.Show();
        }

        private void Maboutus_Click(object sender, EventArgs e)
        {
            MessageBox.Show("We are  our customers be careful when you decide to stay our motel");
            
        }

        private void MCustomerspu_Click(object sender, EventArgs e)
        {
            NewSupport support = new NewSupport();
            support.Show();
            this.Close();
        }

        private void Mwatchtv_Click(object sender, EventArgs e)
        {
            string exeFileAndLocation = @"C:\Users\Nihat\Desktop\sfvip-player-64bit-1.2.3.9\SFVIP-Player-x64\sfvipplayer.exe";
            string arguments = "sampleArgument";
            System.Diagnostics.Process.Start(exeFileAndLocation, arguments);
            this.Close();
        }

        private void Mnewspaper_Click(object sender, EventArgs e)
        {
            Newspaper newspaper = new Newspaper();
            newspaper.Show();
            
        }

        private void Mexit_Click(object sender, EventArgs e)
        {

            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
                label2.Text = DateTime.Now.ToLongDateString();
                label3.Text = DateTime.Now.ToLongTimeString();
            }

        
    }
}
