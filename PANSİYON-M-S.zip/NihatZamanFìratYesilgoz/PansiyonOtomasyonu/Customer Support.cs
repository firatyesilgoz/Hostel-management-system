﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace PansiyonOtomasyonu
{
    public partial class Customer_Support : Form
    {
        public Customer_Support()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void showdatas()
        {
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("select * from messages", baglanti);
            SqlDataReader read = cmd.ExecuteReader();

            while (read.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read["mid"].ToString();
                add.SubItems.Add(read["name"].ToString());
                add.SubItems.Add(read["Messages"].ToString());
               

                listView1.Items.Add(add);
            }
            baglanti.Close();
        }

        private void Customer_Support_Load(object sender, EventArgs e)
        {
            showdatas();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mainpage fr = new Mainpage();
            this.Close();
            fr.Show();
          
        }
        int id = 0;

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            id = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
            textBox1.Text = listView1.SelectedItems[0].SubItems[1].Text;
            richTextBox1.Text= listView1.SelectedItems[0].SubItems[2].Text;
        }
    }
}
