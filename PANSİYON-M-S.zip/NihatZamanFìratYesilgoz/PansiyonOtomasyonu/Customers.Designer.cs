﻿namespace PansiyonOtomasyonu
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customers));
            this.CShowData = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Cupdate = new System.Windows.Forms.Button();
            this.Cdelete = new System.Windows.Forms.Button();
            this.Csearch = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.rtotal = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rcheckoutdate = new System.Windows.Forms.DateTimePicker();
            this.rcheckindate = new System.Windows.Forms.DateTimePicker();
            this.rphone = new System.Windows.Forms.MaskedTextBox();
            this.rroomno = new System.Windows.Forms.TextBox();
            this.rnationalid = new System.Windows.Forms.TextBox();
            this.rmail = new System.Windows.Forms.TextBox();
            this.rsurname = new System.Windows.Forms.TextBox();
            this.rname = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Csearchbox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Cclear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CShowData
            // 
            this.CShowData.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CShowData.ForeColor = System.Drawing.Color.Black;
            this.CShowData.Location = new System.Drawing.Point(641, 12);
            this.CShowData.Name = "CShowData";
            this.CShowData.Size = new System.Drawing.Size(158, 37);
            this.CShowData.TabIndex = 1;
            this.CShowData.Text = "Show Data";
            this.CShowData.UseVisualStyleBackColor = false;
            this.CShowData.Click += new System.EventHandler(this.button1_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(1, 279);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(811, 219);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.DoubleClick += new System.EventHandler(this.listView1_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "id";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "name";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "surname";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "gender";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "phone";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "mail";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "national id";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "room no";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "total";
            this.columnHeader9.Width = 67;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Check_in_Date";
            this.columnHeader10.Width = 139;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Check_out_date";
            this.columnHeader11.Width = 125;
            // 
            // Cupdate
            // 
            this.Cupdate.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cupdate.ForeColor = System.Drawing.Color.Black;
            this.Cupdate.Location = new System.Drawing.Point(641, 67);
            this.Cupdate.Name = "Cupdate";
            this.Cupdate.Size = new System.Drawing.Size(158, 37);
            this.Cupdate.TabIndex = 3;
            this.Cupdate.Text = "Update";
            this.Cupdate.UseVisualStyleBackColor = false;
            this.Cupdate.Click += new System.EventHandler(this.Cupdate_Click);
            // 
            // Cdelete
            // 
            this.Cdelete.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cdelete.ForeColor = System.Drawing.Color.Black;
            this.Cdelete.Location = new System.Drawing.Point(641, 123);
            this.Cdelete.Name = "Cdelete";
            this.Cdelete.Size = new System.Drawing.Size(158, 37);
            this.Cdelete.TabIndex = 4;
            this.Cdelete.Text = "Delete";
            this.Cdelete.UseVisualStyleBackColor = false;
            this.Cdelete.Click += new System.EventHandler(this.Cdelete_Click);
            // 
            // Csearch
            // 
            this.Csearch.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Csearch.ForeColor = System.Drawing.Color.Black;
            this.Csearch.Location = new System.Drawing.Point(641, 179);
            this.Csearch.Name = "Csearch";
            this.Csearch.Size = new System.Drawing.Size(158, 37);
            this.Csearch.TabIndex = 5;
            this.Csearch.Text = "Search";
            this.Csearch.UseVisualStyleBackColor = false;
            this.Csearch.Click += new System.EventHandler(this.Csearch_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Man",
            "Women"});
            this.comboBox1.Location = new System.Drawing.Point(179, 95);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(134, 21);
            this.comboBox1.TabIndex = 60;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(12, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 30);
            this.label10.TabIndex = 59;
            this.label10.Text = "Gender :";
            // 
            // rtotal
            // 
            this.rtotal.Enabled = false;
            this.rtotal.Location = new System.Drawing.Point(486, 15);
            this.rtotal.Name = "rtotal";
            this.rtotal.Size = new System.Drawing.Size(141, 20);
            this.rtotal.TabIndex = 58;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(319, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 30);
            this.label9.TabIndex = 57;
            this.label9.Text = "Total :";
            // 
            // rcheckoutdate
            // 
            this.rcheckoutdate.CalendarFont = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rcheckoutdate.Location = new System.Drawing.Point(486, 95);
            this.rcheckoutdate.Name = "rcheckoutdate";
            this.rcheckoutdate.Size = new System.Drawing.Size(141, 20);
            this.rcheckoutdate.TabIndex = 56;
            // 
            // rcheckindate
            // 
            this.rcheckindate.CalendarFont = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rcheckindate.Location = new System.Drawing.Point(486, 55);
            this.rcheckindate.Name = "rcheckindate";
            this.rcheckindate.Size = new System.Drawing.Size(141, 20);
            this.rcheckindate.TabIndex = 55;
            // 
            // rphone
            // 
            this.rphone.Location = new System.Drawing.Point(179, 135);
            this.rphone.Mask = "(999) 000-0000";
            this.rphone.Name = "rphone";
            this.rphone.Size = new System.Drawing.Size(134, 20);
            this.rphone.TabIndex = 54;
            // 
            // rroomno
            // 
            this.rroomno.Location = new System.Drawing.Point(179, 258);
            this.rroomno.Name = "rroomno";
            this.rroomno.Size = new System.Drawing.Size(134, 20);
            this.rroomno.TabIndex = 53;
            // 
            // rnationalid
            // 
            this.rnationalid.Location = new System.Drawing.Point(179, 218);
            this.rnationalid.Name = "rnationalid";
            this.rnationalid.Size = new System.Drawing.Size(134, 20);
            this.rnationalid.TabIndex = 52;
            // 
            // rmail
            // 
            this.rmail.Location = new System.Drawing.Point(179, 175);
            this.rmail.Name = "rmail";
            this.rmail.Size = new System.Drawing.Size(134, 20);
            this.rmail.TabIndex = 51;
            // 
            // rsurname
            // 
            this.rsurname.Location = new System.Drawing.Point(179, 55);
            this.rsurname.Name = "rsurname";
            this.rsurname.Size = new System.Drawing.Size(134, 20);
            this.rsurname.TabIndex = 50;
            // 
            // rname
            // 
            this.rname.Location = new System.Drawing.Point(179, 15);
            this.rname.Name = "rname";
            this.rname.Size = new System.Drawing.Size(134, 20);
            this.rname.TabIndex = 49;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(319, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(171, 30);
            this.label8.TabIndex = 48;
            this.label8.Text = "Check out Date :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(319, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 30);
            this.label7.TabIndex = 47;
            this.label7.Text = "Check in Date :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(12, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 30);
            this.label6.TabIndex = 46;
            this.label6.Text = "Room No :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(12, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 30);
            this.label5.TabIndex = 45;
            this.label5.Text = "National ID :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(12, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 30);
            this.label4.TabIndex = 44;
            this.label4.Text = "Mail :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(12, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 30);
            this.label3.TabIndex = 43;
            this.label3.Text = "Phone :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 30);
            this.label2.TabIndex = 42;
            this.label2.Text = "Surname :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 30);
            this.label1.TabIndex = 41;
            this.label1.Text = "Name :";
            // 
            // Csearchbox
            // 
            this.Csearchbox.Location = new System.Drawing.Point(648, 227);
            this.Csearchbox.Multiline = true;
            this.Csearchbox.Name = "Csearchbox";
            this.Csearchbox.Size = new System.Drawing.Size(141, 30);
            this.Csearchbox.TabIndex = 62;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(571, 227);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 30);
            this.label11.TabIndex = 61;
            this.label11.Text = "Name :";
            // 
            // Cclear
            // 
            this.Cclear.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Cclear.ForeColor = System.Drawing.Color.Black;
            this.Cclear.Location = new System.Drawing.Point(341, 149);
            this.Cclear.Name = "Cclear";
            this.Cclear.Size = new System.Drawing.Size(257, 46);
            this.Cclear.TabIndex = 63;
            this.Cclear.Text = "Clear";
            this.Cclear.UseVisualStyleBackColor = false;
            this.Cclear.Click += new System.EventHandler(this.Cclear_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(17, 504);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 37);
            this.button1.TabIndex = 64;
            this.button1.Text = "Cback";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(811, 545);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Cclear);
            this.Controls.Add(this.Csearchbox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.rtotal);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.rcheckoutdate);
            this.Controls.Add(this.rcheckindate);
            this.Controls.Add(this.rphone);
            this.Controls.Add(this.rroomno);
            this.Controls.Add(this.rnationalid);
            this.Controls.Add(this.rmail);
            this.Controls.Add(this.rsurname);
            this.Controls.Add(this.rname);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Csearch);
            this.Controls.Add(this.Cdelete);
            this.Controls.Add(this.Cupdate);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.CShowData);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Customers";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Customers_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CShowData;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.Button Cupdate;
        private System.Windows.Forms.Button Cdelete;
        private System.Windows.Forms.Button Csearch;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox rtotal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker rcheckoutdate;
        private System.Windows.Forms.DateTimePicker rcheckindate;
        private System.Windows.Forms.MaskedTextBox rphone;
        private System.Windows.Forms.TextBox rroomno;
        private System.Windows.Forms.TextBox rnationalid;
        private System.Windows.Forms.TextBox rmail;
        private System.Windows.Forms.TextBox rsurname;
        private System.Windows.Forms.TextBox rname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Csearchbox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Cclear;
        private System.Windows.Forms.Button button1;
    }
}