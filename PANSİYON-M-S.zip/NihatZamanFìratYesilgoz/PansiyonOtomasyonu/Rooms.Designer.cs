﻿namespace PansiyonOtomasyonu
{
    partial class Rooms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rooms));
            this.rfilled = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rroom109 = new System.Windows.Forms.Button();
            this.rroom108 = new System.Windows.Forms.Button();
            this.rroom107 = new System.Windows.Forms.Button();
            this.rroom106 = new System.Windows.Forms.Button();
            this.rroom105 = new System.Windows.Forms.Button();
            this.rroom104 = new System.Windows.Forms.Button();
            this.rroom103 = new System.Windows.Forms.Button();
            this.rroom102 = new System.Windows.Forms.Button();
            this.rroom101 = new System.Windows.Forms.Button();
            this.rFree = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // rfilled
            // 
            this.rfilled.BackColor = System.Drawing.Color.Red;
            this.rfilled.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rfilled.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rfilled.Location = new System.Drawing.Point(324, 545);
            this.rfilled.Name = "rfilled";
            this.rfilled.Size = new System.Drawing.Size(78, 41);
            this.rfilled.TabIndex = 13;
            this.rfilled.Text = "Filled";
            this.rfilled.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.rroom109);
            this.groupBox2.Controls.Add(this.rroom108);
            this.groupBox2.Controls.Add(this.rroom107);
            this.groupBox2.Controls.Add(this.rroom106);
            this.groupBox2.Controls.Add(this.rroom105);
            this.groupBox2.Controls.Add(this.rroom104);
            this.groupBox2.Controls.Add(this.rroom103);
            this.groupBox2.Controls.Add(this.rroom102);
            this.groupBox2.Controls.Add(this.rroom101);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(17, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(429, 513);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rooms";
            // 
            // rroom109
            // 
            this.rroom109.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom109.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom109.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom109.Location = new System.Drawing.Point(285, 365);
            this.rroom109.Name = "rroom109";
            this.rroom109.Size = new System.Drawing.Size(129, 61);
            this.rroom109.TabIndex = 8;
            this.rroom109.Text = "109";
            this.rroom109.UseVisualStyleBackColor = false;
            this.rroom109.Click += new System.EventHandler(this.rroom109_Click);
            // 
            // rroom108
            // 
            this.rroom108.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom108.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom108.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom108.Location = new System.Drawing.Point(153, 365);
            this.rroom108.Name = "rroom108";
            this.rroom108.Size = new System.Drawing.Size(129, 61);
            this.rroom108.TabIndex = 7;
            this.rroom108.Text = "108";
            this.rroom108.UseVisualStyleBackColor = false;
            this.rroom108.Click += new System.EventHandler(this.rroom108_Click);
            // 
            // rroom107
            // 
            this.rroom107.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom107.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom107.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom107.Location = new System.Drawing.Point(18, 365);
            this.rroom107.Name = "rroom107";
            this.rroom107.Size = new System.Drawing.Size(129, 61);
            this.rroom107.TabIndex = 6;
            this.rroom107.Text = "107";
            this.rroom107.UseVisualStyleBackColor = false;
            this.rroom107.Click += new System.EventHandler(this.rroom107_Click);
            // 
            // rroom106
            // 
            this.rroom106.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom106.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom106.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom106.Location = new System.Drawing.Point(285, 226);
            this.rroom106.Name = "rroom106";
            this.rroom106.Size = new System.Drawing.Size(129, 67);
            this.rroom106.TabIndex = 5;
            this.rroom106.Text = "106";
            this.rroom106.UseVisualStyleBackColor = false;
            this.rroom106.Click += new System.EventHandler(this.rroom106_Click);
            // 
            // rroom105
            // 
            this.rroom105.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom105.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom105.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom105.Location = new System.Drawing.Point(153, 226);
            this.rroom105.Name = "rroom105";
            this.rroom105.Size = new System.Drawing.Size(129, 67);
            this.rroom105.TabIndex = 4;
            this.rroom105.Text = "105";
            this.rroom105.UseVisualStyleBackColor = false;
            this.rroom105.Click += new System.EventHandler(this.rroom105_Click);
            // 
            // rroom104
            // 
            this.rroom104.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom104.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom104.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom104.Location = new System.Drawing.Point(18, 226);
            this.rroom104.Name = "rroom104";
            this.rroom104.Size = new System.Drawing.Size(129, 67);
            this.rroom104.TabIndex = 3;
            this.rroom104.Text = "104";
            this.rroom104.UseVisualStyleBackColor = false;
            this.rroom104.Click += new System.EventHandler(this.rroom104_Click);
            // 
            // rroom103
            // 
            this.rroom103.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom103.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom103.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom103.Location = new System.Drawing.Point(285, 84);
            this.rroom103.Name = "rroom103";
            this.rroom103.Size = new System.Drawing.Size(129, 62);
            this.rroom103.TabIndex = 2;
            this.rroom103.Text = "103";
            this.rroom103.UseVisualStyleBackColor = false;
            this.rroom103.Click += new System.EventHandler(this.rroom103_Click);
            // 
            // rroom102
            // 
            this.rroom102.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom102.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom102.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom102.Location = new System.Drawing.Point(153, 84);
            this.rroom102.Name = "rroom102";
            this.rroom102.Size = new System.Drawing.Size(129, 62);
            this.rroom102.TabIndex = 1;
            this.rroom102.Text = "102";
            this.rroom102.UseVisualStyleBackColor = false;
            this.rroom102.Click += new System.EventHandler(this.rroom102_Click);
            // 
            // rroom101
            // 
            this.rroom101.BackColor = System.Drawing.Color.YellowGreen;
            this.rroom101.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rroom101.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rroom101.Location = new System.Drawing.Point(18, 84);
            this.rroom101.Name = "rroom101";
            this.rroom101.Size = new System.Drawing.Size(129, 62);
            this.rroom101.TabIndex = 0;
            this.rroom101.Text = "101";
            this.rroom101.UseVisualStyleBackColor = false;
            this.rroom101.Click += new System.EventHandler(this.rroom101_Click);
            // 
            // rFree
            // 
            this.rFree.BackColor = System.Drawing.Color.YellowGreen;
            this.rFree.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rFree.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rFree.Location = new System.Drawing.Point(232, 545);
            this.rFree.Name = "rFree";
            this.rFree.Size = new System.Drawing.Size(78, 41);
            this.rFree.TabIndex = 12;
            this.rFree.Text = "Free";
            this.rFree.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(17, 557);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "RBack";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Rooms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(466, 603);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.rfilled);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.rFree);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Rooms";
            this.Text = "Rooms";
            this.Load += new System.EventHandler(this.Rooms_Load);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button rfilled;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button rroom109;
        private System.Windows.Forms.Button rroom108;
        private System.Windows.Forms.Button rroom107;
        private System.Windows.Forms.Button rroom106;
        private System.Windows.Forms.Button rroom105;
        private System.Windows.Forms.Button rroom104;
        private System.Windows.Forms.Button rroom103;
        private System.Windows.Forms.Button rroom102;
        private System.Windows.Forms.Button rroom101;
        private System.Windows.Forms.Button rFree;
        private System.Windows.Forms.Button button1;
    }
}