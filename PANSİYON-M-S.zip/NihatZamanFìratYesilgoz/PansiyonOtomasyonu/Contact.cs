﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PansiyonOtomasyonu
{
    public partial class Contact : Form
    {
        public Contact()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void showdatas()
        {
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("select * from Contactln", baglanti);
            SqlDataReader read = cmd.ExecuteReader();

            while (read.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read["iletisimid"].ToString();
                add.SubItems.Add(read["tel"].ToString());
                add.SubItems.Add(read["Email"].ToString());



                listView1.Items.Add(add);
            }
            baglanti.Close();
        }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            showdatas();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomerMainPage fr = new CustomerMainPage();
            fr.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
