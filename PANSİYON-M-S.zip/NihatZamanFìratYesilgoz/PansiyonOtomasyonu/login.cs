﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PansiyonOtomasyonu
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminlogin fr = new adminlogin();
            fr.Show();
            this.Close ();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomerMainPage fr= new CustomerMainPage();
            fr.Show();
            this.Close();
        }
    }
}
