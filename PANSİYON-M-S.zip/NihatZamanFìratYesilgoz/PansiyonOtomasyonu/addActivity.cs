﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;

namespace PansiyonOtomasyonu
{
    public partial class addActivity : Form
    {
        public addActivity()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void showdatas()
        {
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand cmd = new SqlCommand("select * from Activty", baglanti);
            SqlDataReader read = cmd.ExecuteReader();

            while (read.Read())
            {
                ListViewItem add = new ListViewItem();
                add.Text = read["acid"].ToString();
                add.SubItems.Add(read["name"].ToString());
                add.SubItems.Add(read["price"].ToString());



                listView1.Items.Add(add);
            }
            baglanti.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            Mainpage fr = new Mainpage();
            fr.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into Activty (name,price) values('" + textBox1.Text + "','" + textBox2.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
        }

        private void CShowData_Click(object sender, EventArgs e)
        {
            showdatas();
        }

        private void Cclear_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox1.Clear();
        }
    }
}
