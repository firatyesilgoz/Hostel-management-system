﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PansiyonOtomasyonu
{
    public partial class Rooms : Form
    {
        public Rooms()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=MotelMoonlight;Integrated Security=True");
        private void Rooms_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand cmd1 = new SqlCommand("select * from room101",baglanti);
            SqlDataReader read1 = cmd1.ExecuteReader();

            while (read1.Read())
            {
                rroom101.Text = read1["Name"].ToString()+""+ read1["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom101.Text != "101")
            {
                rroom101.BackColor= Color.Red;
            }
            //2
            baglanti.Open();
            SqlCommand cmd2 = new SqlCommand("select * from room102", baglanti);
            SqlDataReader read2 = cmd2.ExecuteReader();

            while (read2.Read())
            {
                rroom102.Text = read2["Name"].ToString() + "" + read2["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom102.Text != "102")
            {
                rroom102.BackColor = Color.Red;
            }
            //3
            baglanti.Open();
            SqlCommand cmd3 = new SqlCommand("select * from room103", baglanti);
            SqlDataReader read3 = cmd3.ExecuteReader();

            while (read3.Read())
            {
                rroom103.Text = read3["Name"].ToString() + "" + read3["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom103.Text != "103")
            {
                rroom103.BackColor = Color.Red;
            }
            //4
            baglanti.Open();
            SqlCommand cmd4 = new SqlCommand("select * from room104", baglanti);
            SqlDataReader read4 = cmd4.ExecuteReader();

            while (read4.Read())
            {
                rroom104.Text = read4["Name"].ToString() + "" + read4["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom104.Text != "104")
            {
                rroom104.BackColor = Color.Red;
            }
            //5
            baglanti.Open();
            SqlCommand cmd5 = new SqlCommand("select * from room105", baglanti);
            SqlDataReader read5 = cmd5.ExecuteReader();

            while (read5.Read())
            {
                rroom105.Text = read5["Name"].ToString() + "" + read5["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom105.Text != "105")
            {
                rroom105.BackColor = Color.Red;
            }
            //6
            baglanti.Open();
            SqlCommand cmd6 = new SqlCommand("select * from room106", baglanti);
            SqlDataReader read6 = cmd6.ExecuteReader();

            while (read6.Read())
            {
                rroom106.Text = read6["Name"].ToString() + "" + read6["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom106.Text != "106")
            {
                rroom106.BackColor = Color.Red;
            }
            //7
            baglanti.Open();
            SqlCommand cmd7 = new SqlCommand("select * from room107", baglanti);
            SqlDataReader read7 = cmd7.ExecuteReader();

            while (read7.Read())
            {
                rroom107.Text = read7["Name"].ToString() + "" + read7["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom107.Text != "107")
            {
                rroom107.BackColor = Color.Red;
            }
            //8
            baglanti.Open();
            SqlCommand cmd8 = new SqlCommand("select * from room108", baglanti);
            SqlDataReader read8 = cmd8.ExecuteReader();

            while (read8.Read())
            {
                rroom108.Text = read8["Name"].ToString() + "" + read8["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom108.Text != "108")
            {
                rroom108.BackColor = Color.Red;
            }
            //9
            baglanti.Open();
            SqlCommand cmd9 = new SqlCommand("select * from room109", baglanti);
            SqlDataReader read9 = cmd9.ExecuteReader();

            while (read9.Read())
            {
                rroom109.Text = read9["Name"].ToString() + "" + read9["Surname"].ToString();
            }
            baglanti.Close();
            if (rroom109.Text != "109")
            {
                rroom109.BackColor = Color.Red;
            }
        }

        private void rroom101_Click(object sender, EventArgs e)
        {

        }

        private void rroom108_Click(object sender, EventArgs e)
        {

        }

        private void rroom107_Click(object sender, EventArgs e)
        {

        }

        private void rroom106_Click(object sender, EventArgs e)
        {

        }

        private void rroom109_Click(object sender, EventArgs e)
        {

        }

        private void rroom104_Click(object sender, EventArgs e)
        {

        }

        private void rroom103_Click(object sender, EventArgs e)
        {

        }

        private void rroom102_Click(object sender, EventArgs e)
        {

        }

        private void rroom105_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mainpage fr = new Mainpage();
            fr.Show();
            this.Close();
        }
    }
}
