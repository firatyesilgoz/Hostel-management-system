﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;

namespace PansiyonOtomasyonu
{
    public partial class NewSupport : Form
    {
        public NewSupport()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-340M9CG;Initial Catalog=Motel;Integrated Security=True");
        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into messages (name,Messages) values('" + textBox1.Text + "','" + richTextBox1.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Your message has been succesfully delivered");
            baglanti.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CustomerMainPage fr = new CustomerMainPage();
            fr.Show ();
            this.Close();
        }
    }
}
